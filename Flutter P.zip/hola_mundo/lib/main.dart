import 'package:flutter/material.dart';
import 'package:hola_mundo/src/app.dart';

void main() {
  runApp(Myapp());
}
